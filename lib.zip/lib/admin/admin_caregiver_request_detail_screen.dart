import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

class AdminCaregiverRequestDetailScreen extends StatelessWidget {
  final String caregiverId;
  const AdminCaregiverRequestDetailScreen({super.key, required this.caregiverId});

  Future<String?> _askReason(BuildContext context, String title) async {
    final c = TextEditingController();
    final res = await showDialog<String?>(
      context: context,
      builder: (_) => AlertDialog(
        title: Text(title),
        content: TextField(
          controller: c,
          maxLines: 3,
          decoration: const InputDecoration(hintText: 'Reason (required)'),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, null), child: const Text('Cancel')),
          ElevatedButton(onPressed: () => Navigator.pop(context, c.text.trim()), child: const Text('Submit')),
        ],
      ),
    );
    c.dispose();
    return res;
  }

  bool _isImageUrl(String url) {
    final u = url.toLowerCase();
    return u.endsWith('.png') || u.endsWith('.jpg') || u.endsWith('.jpeg') || u.endsWith('.webp');
  }

  Future<void> _copy(BuildContext context, String text) async {
    await Clipboard.setData(ClipboardData(text: text));
    if (context.mounted) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Link copied')));
    }
  }

  @override
  Widget build(BuildContext context) {
    final ref = FirebaseFirestore.instance.collection('caregivers').doc(caregiverId);

    return Scaffold(
      appBar: AppBar(title: const Text('Request Details')),
      body: StreamBuilder<DocumentSnapshot<Map<String, dynamic>>>(
        stream: ref.snapshots(),
        builder: (context, snap) {
          if (snap.hasError) return Center(child: Text('Error: ${snap.error}'));
          if (!snap.hasData) return const Center(child: CircularProgressIndicator());

          final data = snap.data!.data();
          if (data == null) return const Center(child: Text('Not found'));

          final name = (data['fullName'] as String?) ?? 'Unknown';
          final email = (data['email'] as String?) ?? '';
          final phone = (data['phone'] as String?) ?? '';
          final city = (data['city'] as String?) ?? '';
          final exp = data['experienceYears'];
          final rate = data['hourlyRate'];
          final bio = (data['bio'] as String?) ?? '';
          final status = (data['status'] as String?) ?? '';
          final reason = (data['statusReason'] as String?) ?? '';

          final langs = (data['languages'] as List?)?.cast<dynamic>() ?? const [];
          final specs = (data['specialties'] as List?)?.cast<dynamic>() ?? const [];

          final docs = (data['documents'] as Map?)?.cast<String, dynamic>() ?? {};
          // show these first (if you use these keys)
          final nicFront = (docs['nicFrontUrl'] as String?) ?? '';
          final nicBack = (docs['nicBackUrl'] as String?) ?? '';

          Future<void> verify() async {
            final adminId = FirebaseAuth.instance.currentUser?.uid;
            if (adminId == null) return;

            await ref.set({
              'status': 'VERIFIED',
              'isVerified': true,
              'isActive': false,
              'statusReason': '',
              'verifiedAt': FieldValue.serverTimestamp(),
              'verifiedBy': adminId,
              'updatedAt': FieldValue.serverTimestamp(),
            }, SetOptions(merge: true));
            if (context.mounted) Navigator.pop(context);
          }

          Future<void> reject() async {
            final adminId = FirebaseAuth.instance.currentUser?.uid;
            if (adminId == null) return;

            final r = await _askReason(context, 'Reject caregiver');
            if (r == null || r.isEmpty) return;

            await ref.set({
              'status': 'REJECTED',
              'isVerified': false,
              'isActive': false,
              'statusReason': r,
              'rejectedAt': FieldValue.serverTimestamp(),
              'rejectedBy': adminId,
              'updatedAt': FieldValue.serverTimestamp(),
            }, SetOptions(merge: true));
          }

          Future<void> block() async {
            final adminId = FirebaseAuth.instance.currentUser?.uid;
            if (adminId == null) return;

            final r = await _askReason(context, 'Block caregiver');
            if (r == null || r.isEmpty) return;

            await ref.set({
              'status': 'BLOCKED',
              'isVerified': false,
              'isActive': false,
              'statusReason': r,
              'blockedAt': FieldValue.serverTimestamp(),
              'blockedBy': adminId,
              'updatedAt': FieldValue.serverTimestamp(),
            }, SetOptions(merge: true));
          }

          Future<void> unblock() async {
            final adminId = FirebaseAuth.instance.currentUser?.uid;
            if (adminId == null) return;

            await ref.set({
              'status': 'PENDING_VERIFICATION',
              'isVerified': false,
              'isActive': false,
              'statusReason': '',
              'unblockedAt': FieldValue.serverTimestamp(),
              'unblockedBy': adminId,
              'updatedAt': FieldValue.serverTimestamp(),
            }, SetOptions(merge: true));
          }

          Widget docCard(String title, String url) {
            if (url.trim().isEmpty) {
              return ListTile(
                leading: const Icon(Icons.warning_amber),
                title: Text(title),
                subtitle: const Text('Missing'),
              );
            }

            return Card(
              child: Padding(
                padding: const EdgeInsets.all(12),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(title, style: const TextStyle(fontWeight: FontWeight.bold)),
                    const SizedBox(height: 10),
                    if (_isImageUrl(url))
                      ClipRRect(
                        borderRadius: BorderRadius.circular(12),
                        child: Image.network(
                          url,
                          height: 220,
                          width: double.infinity,
                          fit: BoxFit.cover,
                          errorBuilder: (_, __, ___) => const Text('Cannot preview image'),
                        ),
                      )
                    else
                      SelectableText(url, maxLines: 2),
                    const SizedBox(height: 10),
                    Align(
                      alignment: Alignment.centerRight,
                      child: OutlinedButton.icon(
                        onPressed: () => _copy(context, url),
                        icon: const Icon(Icons.copy),
                        label: const Text('Copy link'),
                      ),
                    ),
                  ],
                ),
              ),
            );
          }

          // show remaining docs (optional)
          final otherDocEntries = docs.entries
              .where((e) => e.key != 'nicFrontUrl' && e.key != 'nicBackUrl')
              .where((e) => e.value is String && (e.value as String).trim().isNotEmpty)
              .toList();

          return ListView(
            padding: const EdgeInsets.all(16),
            children: [
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(name, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                      const SizedBox(height: 8),
                      if (email.isNotEmpty) Text('Email: $email'),
                      if (phone.isNotEmpty) Text('Phone: $phone'),
                      if (city.isNotEmpty) Text('City: $city'),
                      Text('Experience: ${exp ?? '-'}'),
                      Text('Hourly rate: ${rate ?? '-'}'),
                      const SizedBox(height: 10),
                      Text('Status: $status', style: const TextStyle(fontWeight: FontWeight.bold)),
                      if (reason.trim().isNotEmpty) Text('Reason: $reason', style: const TextStyle(color: Colors.red)),
                      if (bio.trim().isNotEmpty) ...[
                        const SizedBox(height: 10),
                        const Text('Bio', style: TextStyle(fontWeight: FontWeight.bold)),
                        Text(bio),
                      ],
                      if (langs.isNotEmpty) ...[
                        const SizedBox(height: 10),
                        const Text('Languages', style: TextStyle(fontWeight: FontWeight.bold)),
                        Wrap(spacing: 8, children: langs.map((e) => Chip(label: Text('$e'))).toList()),
                      ],
                      if (specs.isNotEmpty) ...[
                        const SizedBox(height: 10),
                        const Text('Specialties', style: TextStyle(fontWeight: FontWeight.bold)),
                        Wrap(spacing: 8, children: specs.map((e) => Chip(label: Text('$e'))).toList()),
                      ],
                    ],
                  ),
                ),
              ),

              const SizedBox(height: 12),
              const Text('Documents', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
              const SizedBox(height: 8),
              docCard('NIC Front', nicFront),
              docCard('NIC Back', nicBack),
              for (final e in otherDocEntries)
                docCard(e.key, e.value as String),

              const SizedBox(height: 12),
              const Text('Admin Actions', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
              const SizedBox(height: 8),

              if (status == 'BLOCKED') ...[
                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton(
                    onPressed: unblock,
                    child: const Text('Unblock (move to pending)'),
                  ),
                ),
              ] else ...[
                Row(
                  children: [
                    Expanded(child: ElevatedButton(onPressed: verify, child: const Text('Verify'))),
                    const SizedBox(width: 10),
                    Expanded(child: OutlinedButton(onPressed: reject, child: const Text('Reject'))),
                  ],
                ),
                const SizedBox(height: 10),
                SizedBox(
                  width: double.infinity,
                  child: OutlinedButton.icon(
                    icon: const Icon(Icons.block),
                    onPressed: block,
                    label: const Text('Block'),
                  ),
                ),
              ],
            ],
          );
        },
      ),
    );
  }
}
