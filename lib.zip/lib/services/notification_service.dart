import 'package:flutter/foundation.dart' show kIsWeb, defaultTargetPlatform, TargetPlatform;
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:timezone/data/latest.dart' as tz;
import 'package:timezone/timezone.dart' as tz;

/// Local notifications wrapper.
///
/// - Android/iOS/macOS: supported.
/// - Web: no-op (keeps the app compiling/running on Flutter Web).
class NotificationService {
  static final FlutterLocalNotificationsPlugin _notificationsPlugin =
      FlutterLocalNotificationsPlugin();

  static bool _initialized = false;

  static bool get _isAndroid =>
      !kIsWeb && defaultTargetPlatform == TargetPlatform.android;
  static bool get _isIOS => !kIsWeb && defaultTargetPlatform == TargetPlatform.iOS;
  static bool get _isMacOS =>
      !kIsWeb && defaultTargetPlatform == TargetPlatform.macOS;

  /// Initialize notifications + timezone.
  static Future<void> init() async {
    if (kIsWeb || _initialized) return;

    // Init timezone database.
    try {
      tz.initializeTimeZones();
      // If you want device-detected timezone, integrate a timezone plugin.
      // For now we keep it stable for Sri Lanka.
      tz.setLocalLocation(tz.getLocation('Asia/Colombo'));
    } catch (_) {
      // If timezone init fails, scheduling still works on many devices using defaults.
    }

    const androidSettings = AndroidInitializationSettings('@mipmap/ic_launcher');
    const darwinSettings = DarwinInitializationSettings(
      requestAlertPermission: false,
      requestBadgePermission: false,
      requestSoundPermission: false,
    );

    const initSettings = InitializationSettings(
      android: androidSettings,
      iOS: darwinSettings,
      macOS: darwinSettings,
    );

    await _notificationsPlugin.initialize(initSettings);
    _initialized = true;
  }

  /// Ask runtime permissions.
  static Future<void> requestPermissions() async {
    if (kIsWeb) return;

    // iOS
    if (_isIOS) {
      final ios = _notificationsPlugin
          .resolvePlatformSpecificImplementation<IOSFlutterLocalNotificationsPlugin>();
      await ios?.requestPermissions(alert: true, badge: true, sound: true);
      return;
    }

    // macOS
    if (_isMacOS) {
      final mac = _notificationsPlugin.resolvePlatformSpecificImplementation<
          MacOSFlutterLocalNotificationsPlugin>();
      await mac?.requestPermissions(alert: true, badge: true, sound: true);
      return;
    }

    // Android 13+ notifications + exact alarms (best-effort, API depends on plugin version).
    if (_isAndroid) {
      final android = _notificationsPlugin.resolvePlatformSpecificImplementation<
          AndroidFlutterLocalNotificationsPlugin>();
      if (android == null) return;

      try {
        await (android as dynamic).requestNotificationsPermission();
      } catch (_) {
        // Older plugin versions don't expose this.
      }

      try {
        await (android as dynamic).requestExactAlarmsPermission();
      } catch (_) {
        // Older plugin versions don't expose this.
      }
    }
  }

  static NotificationDetails _details() {
    const android = AndroidNotificationDetails(
      'medication_reminders',
      'Medication Reminders',
      channelDescription: 'Medication reminders for seniors',
      importance: Importance.max,
      priority: Priority.high,
    );

    const darwin = DarwinNotificationDetails(
      presentAlert: true,
      presentBadge: true,
      presentSound: true,
    );

    return const NotificationDetails(android: android, iOS: darwin, macOS: darwin);
  }

  /// Show an immediate notification.
  static Future<void> showNow({
    required int id,
    required String title,
    required String body,
    String? payload,
  }) async {
    if (kIsWeb) return;
    await _notificationsPlugin.show(id, title, body, _details(), payload: payload);
  }

  /// Schedule a one-time notification at [dateTime].
  static Future<void> scheduleOnce({
    required int id,
    required String title,
    required String body,
    required DateTime dateTime,
    String? payload,
  }) async {
    if (kIsWeb) return;

    final scheduled = tz.TZDateTime.from(dateTime, tz.local);
    await _notificationsPlugin.zonedSchedule(
      id,
      title,
      body,
      scheduled,
      _details(),
      androidScheduleMode: AndroidScheduleMode.exactAllowWhileIdle,
      uiLocalNotificationDateInterpretation:
          UILocalNotificationDateInterpretation.absoluteTime,
      payload: payload,
    );
  }

  /// Schedule a daily notification at the time contained in [scheduledDate].
  ///
  /// Tip: pass the *next occurrence* of the desired time (not a time in the past).
  static Future<void> scheduleDaily({
    required int id,
    required String title,
    required String body,
    required DateTime scheduledDate,
    String? payload,
  }) async {
    if (kIsWeb) return;

    final scheduled = tz.TZDateTime.from(scheduledDate, tz.local);
    await _notificationsPlugin.zonedSchedule(
      id,
      title,
      body,
      scheduled,
      _details(),
      androidScheduleMode: AndroidScheduleMode.exactAllowWhileIdle,
      uiLocalNotificationDateInterpretation:
          UILocalNotificationDateInterpretation.absoluteTime,
      matchDateTimeComponents: DateTimeComponents.time,
      payload: payload,
    );
  }

  static Future<void> cancel(int id) async {
    if (kIsWeb) return;
    await _notificationsPlugin.cancel(id);
  }

  static Future<void> cancelMany(List<int> ids) async {
    if (kIsWeb) return;
    for (final id in ids) {
      await _notificationsPlugin.cancel(id);
    }
  }
}
