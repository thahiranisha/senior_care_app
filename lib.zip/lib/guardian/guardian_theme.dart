import 'package:flutter/material.dart';

class GuardianTheme {
  static const Color primary = Colors.teal;
  static const Color background = Color(0xFFF3FAF9);
}
